"""Synthetic energy-source availability profiles.

Every generator returns a Block: a representative period as a list of slots, each slot a
power-availability fraction p in [0, 1] of the electrolyser's rated power, plus optional
per-slot fast-dynamics flags (cloud flicker, FCR regulation, wave/gust oscillation).
Profiles are synthetic and seeded, so every scenario is reproducible.
"""
import math
import numpy as np

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
SEASON_IDX = {"winter": -1.0, "spring": 0.0, "summer": 1.0, "autumn": 0.0}


class Block:
    def __init__(self, name, p, slot_s=3600, fast=None, label=None, day_slots=24):
        self.name = name                    # e.g. "Summer week"
        self.p = [float(min(1.0, max(0.0, x))) for x in p]
        self.slot_s = slot_s                # seconds per slot (3600 = hourly)
        self.fast = fast or {}              # slot index -> PostStep kind
        self.label = label or name
        self.day_slots = day_slots          # slots per (possibly compressed) day

    @property
    def hours(self):
        return len(self.p) * self.slot_s / 3600.0


# ---------------------------------------------------------------- PV
PV_SITES = {
    # day-length swing (h), winter peak factor, cloud probs per season (clear, partly, overcast)
    "desert":   dict(swing=1.6, wpeak=0.78, clouds={"winter": (.80, .15, .05), "spring": (.85, .12, .03), "summer": (.90, .08, .02), "autumn": (.85, .12, .03)}),
    "midlat":   dict(swing=4.2, wpeak=0.35, clouds={"winter": (.15, .35, .50), "spring": (.30, .45, .25), "summer": (.40, .45, .15), "autumn": (.20, .40, .40)}),
    "nordic":   dict(swing=6.5, wpeak=0.12, clouds={"winter": (.15, .30, .55), "spring": (.35, .40, .25), "summer": (.40, .40, .20), "autumn": (.15, .35, .50)}),
    "tropical": dict(swing=0.4, wpeak=0.92, clouds={"winter": (.40, .45, .15), "spring": (.30, .50, .20), "summer": (.20, .55, .25), "autumn": (.30, .50, .20)}),
    "tracking": dict(swing=2.5, wpeak=0.62, clouds={"winter": (.55, .30, .15), "spring": (.65, .25, .10), "summer": (.75, .20, .05), "autumn": (.60, .28, .12)}),
}


def pv_week(rng, site, season, flicker=True, tracker=False, days=7):
    s = PV_SITES[site]
    k = SEASON_IDX[season]
    daylen = 12 + s["swing"] * k
    sunrise = 12 - daylen / 2
    peak = s["wpeak"] + (1 - s["wpeak"]) * (k + 1) / 2
    probs = s["clouds"][season]
    p, fast = [], {}
    for d in range(days):
        state = rng.choice(3, p=probs)            # 0 clear, 1 partly, 2 overcast
        for h in range(24):
            x = (h + 0.5 - sunrise) / daylen
            if x <= 0 or x >= 1:
                p.append(0.0); continue
            shape = math.sin(math.pi * x) ** (0.45 if tracker else 1.25)
            if site == "tropical" and h >= 13 and rng.random() < 0.55:
                cf = rng.uniform(0.25, 0.7)          # afternoon convection
                st = 1
            elif state == 0:
                cf, st = rng.uniform(0.93, 1.0), 0
            elif state == 1:
                cf, st = rng.uniform(0.45, 0.9), 1
            else:
                cf, st = rng.uniform(0.15, 0.35), 2
            v = peak * shape * cf
            p.append(v)
            if flicker and st == 1 and v > 0.3 and rng.random() < 0.35:
                fast[len(p) - 1] = "flicker"
    return p, fast


# ---------------------------------------------------------------- Wind
WIND_SITES = {
    "onshore":  dict(mean={"winter": 8.6, "spring": 7.6, "summer": 6.4, "autumn": 7.9}, sd=3.0, phi=0.93, storms=0.0),
    "offshore": dict(mean={"winter": 11.0, "spring": 9.4, "summer": 8.1, "autumn": 10.4}, sd=3.6, phi=0.95, storms=0.012),
    "lowwind":  dict(mean={"winter": 6.3, "spring": 5.8, "summer": 4.9, "autumn": 6.0}, sd=2.4, phi=0.92, storms=0.0),
    "coastal":  dict(mean={"winter": 7.0, "spring": 7.0, "summer": 6.8, "autumn": 6.9}, sd=2.2, phi=0.90, storms=0.0, diurnal=2.4),
    "monsoon":  dict(mean={"winter": 5.0, "spring": 6.2, "summer": 10.2, "autumn": 6.6}, sd=2.8, phi=0.94, storms=0.004),
}


def wind_power(v):
    if v < 3 or v >= 25:
        return 0.0
    if v >= 12:
        return 1.0
    return ((v - 3) / 9.0) ** 3


def wind_speeds(rng, site, season, n=168):
    s = WIND_SITES[site]
    z, out, storm = rng.normal(), [], 0
    for i in range(n):
        z = s["phi"] * z + math.sqrt(1 - s["phi"] ** 2) * rng.normal()
        v = s["mean"][season] + s["sd"] * z
        if "diurnal" in s:
            v += s["diurnal"] * math.sin(2 * math.pi * ((i % 24) - 9) / 24)
        if storm == 0 and rng.random() < s["storms"]:
            storm = int(rng.integers(2, 7))
        if storm:
            v = rng.uniform(25.5, 30); storm -= 1
        out.append(max(0.0, v))
    return out


def wind_week(rng, site, season, gusts=False, n=168):
    v = wind_speeds(rng, site, season, n)
    p = [wind_power(x) for x in v]
    fast = {}
    if gusts:
        for i, x in enumerate(p):
            if 0.35 < x < 0.95 and rng.random() < 0.2:
                fast[i] = "gust"
    return p, fast


# ---------------------------------------------------------------- Others
def smooth(x, w):
    x = np.asarray(x, float)
    k = np.ones(w) / w
    pad = np.concatenate([x[-w:], x, x[:w]])
    return list(np.convolve(pad, k, mode="same")[w:-w])


def battery_shift(p, hours=4.0, threshold=0.7, floor=0.35):
    """Simple battery: store energy above `threshold`, release it when p < floor."""
    soc, cap, out = 0.0, hours * 1.0, []
    for x in p:
        if x > threshold:
            charge = min(x - threshold, cap - soc); soc += charge * 0.92; out.append(x - charge)
        elif x < floor and soc > 0:
            give = min(floor - x, soc); soc -= give; out.append(x + give)
        else:
            out.append(x)
    return out


def price_week(rng, season):
    prices = []
    for d in range(7):
        for h in range(24):
            base = 55 + 22 * (math.exp(-((h - 8.5) / 1.6) ** 2) + math.exp(-((h - 19) / 2.0) ** 2))
            if season in ("summer", "spring"):
                base -= 28 * math.exp(-((h - 13) / 2.5) ** 2)
            if d >= 5:
                base -= 15
            prices.append(base + rng.normal(0, 6))
    return prices


def carbon_week(rng, season):
    pv, _ = pv_week(rng, "midlat", season, flicker=False)
    w, _ = wind_week(rng, "onshore", season)
    return [450 - 260 * a - 220 * b + rng.normal(0, 15) for a, b in zip(pv, w)]


def tidal_week(rng, offset_h=0.0):
    p = []
    for i in range(168):
        t = i + 0.5 + offset_h
        spring_neap = 0.62 + 0.38 * math.cos(2 * math.pi * t / 354.4)
        p.append(min(1.0, (abs(math.sin(2 * math.pi * t / 12.42)) ** 1.6) * spring_neap * 1.15))
    return p
