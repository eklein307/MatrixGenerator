"""Generate 100 PEM-electrolysis test scripts (tool JSON format), simulate their set points,
verify duration / ramp-rate / interlock rules, and draw set-point preview graphs.

Usage:  python3 gen.py            -> writes build/json/*.json, build/graphs/*.png, build/catalog.json
The JSON files are then converted to .xlsx by batch_xlsx.js using the Test Script Generator's
own writer and checker, so the sheets are identical to what the tool produces.
"""
import json, math, os, re, sys
import numpy as np
import scenarios as SC
import profiles as P

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build")
WATER = 100            # mL/min, constant during the test
RAMP_J = 30            # s, default ramp for current changes
S_PER_DEGC = 30        # 2 degC/min
S_PER_BAR = 60         # 1 bar/min
REF_J = 1.0            # A/cm2 reference point for diagnostics
REF_HOLD = 1800        # s
PURGE_MIN_IDLE = 6 * 3600
IDLE_T = 40
PROT_J = 0.02
SETTLE_EST = 360       # s, estimated Wait Til Settled time (Set Time 300 + 60)
DIAG_PS = "Diagnostics"

FAST_PS = {   # kind -> (PostStep name, seconds)
    "flicker": ("Cloud flicker", 600),
    "gust": ("Wind gusts", 305),
    "wave": ("Wave oscillation", 304),
    "fcr": ("FCR regulation", 1810),
}
XOVER_PS = ("Crossover check", 1)


def rnd(x, q=0.05):
    return round(round(x / q) * q, 2)


# ============================================================ state helpers
class St:
    __slots__ = ("psu", "j", "T", "P", "purge")

    def __init__(self, psu, j, T, P, purge=False):
        self.psu, self.j, self.T, self.P, self.purge = psu, round(j, 2), T, P, purge

    def key(self):
        return (self.psu, self.j, self.T, self.P, self.purge)

    def __eq__(self, o):
        return self.key() == o.key()


def ramp_needed(a, b):
    r = 0
    if a.j != b.j:
        r = RAMP_J
    r = max(r, abs(a.T - b.T) * S_PER_DEGC, abs(a.P - b.P) * S_PER_BAR)
    return int(math.ceil(r / 10.0) * 10)


# ============================================================ scenario -> blocks
def blocks_for(sc, rng):
    src = SC.SOURCES[sc["source"]]
    kind, fn, v = src[2], src[3], sc["variant"]
    if kind == "seasonal":
        order = SC.SEASONS[sc["vi"] % 4:] + SC.SEASONS[:sc["vi"] % 4]
        out = []
        for s in order:
            p, f = fn(rng, s, v)
            out.append(P.Block(f"{s.capitalize()} week", p, fast=f, label=s[:2].upper()))
        return kind, out
    if kind in ("single", "outage"):
        p, f = fn(rng, "spring", v)
        bl = [P.Block("Representative week", p, fast=f, label="WK")]
        if kind == "outage":
            bl.append(P.Block("Refuelling outage (2 weeks, no power)", [0.0] * 336, label="OUT"))
        return kind, bl
    if kind == "accel":
        p, f = fn(rng, None, v)
        slot = SC.ACCEL_SLOT[sc["source"]]
        return kind, [P.Block("Compressed cycle block", p, slot_s=slot, fast=f, label="AC")]
    raise ValueError(kind)


def slot_states(block, v):
    jr, jmin = v["jr"], round(v["jr"] * v["jmin_frac"], 2)
    out = []
    for p in block.p:
        jt = rnd(p * jr)
        s = v["strategy"]
        if s == "minload":
            st = St(True, max(jt, jmin), v["T"], v["P"])
        elif s == "protective":
            st = St(True, jt if jt >= jmin else PROT_J, v["T"], v["P"])
        else:  # standby / purge
            st = St(True, jt, v["T"], v["P"]) if jt >= jmin else St(False, 0.0, v["T"], v["P"])
        out.append(st)
    return out, jmin


def slot_label(block, i):
    if block.slot_s == 3600:
        d, h = divmod(i, 24)
        return f"{P.DAYS[d % 7]} {h:02d}:00"
    d, h = divmod(i, block.day_slots)
    return f"D{d + 1:02d} {h:02d}h"


def describe(st, jmin, strategy):
    if not st.psu:
        return "idle, PSU off"
    if st.j == PROT_J and strategy == "protective":
        return "protective current"
    if st.j == jmin and strategy in ("minload",):
        return f"min load {st.j:.2f}"
    return f"{st.j:.2f} A/cm2"


# ============================================================ rows
def block_rows(block, v, has_fast):
    """Return list of row dicts (state, time, poststep, comment) for one iteration of a block."""
    states, jmin = slot_states(block, v)
    segs = []                                   # (start, n, state, fast)
    for i, st in enumerate(states):
        fk = block.fast.get(i) if st.psu and st.j > 0.25 else None
        if segs and fk is None and segs[-1][3] is None and segs[-1][2] == st:
            s0, n, _, _ = segs[-1]; segs[-1] = (s0, n + 1, st, None)
        else:
            segs.append((i, 1, st, fk))
    rows = []
    for (s0, n, st, fk) in segs:
        t = n * block.slot_s
        lab = slot_label(block, s0)
        span = f"+{t / 3600:g}h" if block.slot_s == 3600 else f"+{t / 60:g}min"
        if v["strategy"] == "purge" and not st.psu and t >= PURGE_MIN_IDLE:
            cold = St(False, 0.0, IDLE_T, 0)
            hot = St(False, 0.0, v["T"], v["P"])
            r_down = ramp_needed(st, cold); r_up = ramp_needed(cold, hot)
            t_down, t_purge, t_up = r_down + 60, 900, r_up + 60
            rest = t - t_down - t_purge - t_up
            assert rest > 0
            rows += [
                dict(st=cold, time=t_down, ps=None, comment=f"{lab} {span} idle: depressurise, cool to {IDLE_T} C"),
                dict(st=St(False, 0.0, IDLE_T, 0, True), time=t_purge, ps=None, comment=f"{lab} N2 purge 15 min"),
                dict(st=cold, time=rest, ps=None, comment=f"{lab} idle under N2 blanket"),
                dict(st=hot, time=t_up, ps=None, comment=f"{lab} reheat to {v['T']} C, repressurise"),
            ]
            continue
        ps = None
        if fk:
            ps = FAST_PS[fk][0]
        elif st.psu and st.j <= max(jmin, PROT_J) and v["strategy"] in ("minload", "protective"):
            ps = XOVER_PS[0]
        rows.append(dict(st=st, time=t, ps=ps, comment=f"{lab} {span} {describe(st, jmin, v['strategy'])}"))
    return rows, jmin


def ps_time(name, v):
    for k, (n, t) in FAST_PS.items():
        if n == name:
            return t
    if name == XOVER_PS[0]:
        return XOVER_PS[1]
    if name == DIAG_PS:
        return diag_time(v)
    return 0


def diag_steps(v):
    return int(round(v["jr"] / 0.25))


def diag_time(v):
    return 5 + SETTLE_EST + diag_steps(v) * 120 + 30


def poststeps(v, used, jmin):
    ps = []
    if DIAG_PS in used:
        ps.append({"name": DIAG_PS, "steps": [
            {"type": "Conditional", "comment": "End-of-life flag after the reference hold at 1.0 A/cm2",
             "fields": [["Duration", 5], ["MODE", "AND"], ["IF", "CELL_VOLTAGE_FB"], ["GE", 2.1], ["THEN", ""],
                        ["MATRIX_COMMENT", "EoL flag: V at 1.0 A/cm2 >= 2.1 V"]]},
            {"type": "Wait Til Settled", "fields": [["MODE", "AND"], ["Duration", 1800], ["Condition", "Stable"],
                                                    ["Tag Value", "TEMP_FB"], ["Setpoint", "$TEMP_SP"], ["Range", 1], ["Set Time", 300]]},
            {"type": "For", "comment": f"Polarisation curve 0.25 to {v['jr']:.2f} A/cm2, 2 min per point",
             "fields": [["For", "CountB"], ["=", 1], ["To", diag_steps(v)], ["Step", 1]]},
            {"type": "Ramp", "fields": [["Duration", 10], ["CURRENT_DENSITY_SP", "$CountB * 0.25"]]},
            {"type": "Update", "fields": [["Duration", 110], ["MATRIX_COMMENT", "Diagnostics: polarisation curve"]]},
            {"type": "Next", "fields": [["Next", "CountB"]]},
            {"type": "Ramp", "fields": [["Duration", 30], ["CURRENT_DENSITY_SP", REF_J]]},
        ]})
    if FAST_PS["flicker"][0] in used:
        ps.append({"name": FAST_PS["flicker"][0], "steps": [
            {"type": "For", "comment": "10 passing clouds: 40 % of base load for 30 s, then back", "fields": [["For", "CountB"], ["=", 1], ["To", 10], ["Step", 1]]},
            {"type": "Ramp", "fields": [["Duration", 5], ["CURRENT_DENSITY_SP", "$BASE_CD * 0.4"]]},
            {"type": "Update", "fields": [["Duration", 25]]},
            {"type": "Ramp", "fields": [["Duration", 5], ["CURRENT_DENSITY_SP", "$BASE_CD"]]},
            {"type": "Update", "fields": [["Duration", 25]]},
            {"type": "Next", "fields": [["Next", "CountB"]]},
        ]})
    if FAST_PS["gust"][0] in used:
        ps.append({"name": FAST_PS["gust"][0], "steps": [
            {"type": "For", "comment": "10 gusts: +/-25 % of base load, 30 s period", "fields": [["For", "CountB"], ["=", 1], ["To", 10], ["Step", 1]]},
            {"type": "Ramp", "fields": [["Duration", 5], ["CURRENT_DENSITY_SP", "$BASE_CD * 1.25"]]},
            {"type": "Update", "fields": [["Duration", 10]]},
            {"type": "Ramp", "fields": [["Duration", 5], ["CURRENT_DENSITY_SP", "$BASE_CD * 0.75"]]},
            {"type": "Update", "fields": [["Duration", 10]]},
            {"type": "Next", "fields": [["Next", "CountB"]]},
            {"type": "Ramp", "fields": [["Duration", 5], ["CURRENT_DENSITY_SP", "$BASE_CD"]]},
        ]})
    if FAST_PS["wave"][0] in used:
        ps.append({"name": FAST_PS["wave"][0], "steps": [
            {"type": "For", "comment": "30 waves: +/-30 % of base load, 10 s period", "fields": [["For", "CountB"], ["=", 1], ["To", 30], ["Step", 1]]},
            {"type": "Ramp", "fields": [["Duration", 4], ["CURRENT_DENSITY_SP", "$BASE_CD * 1.3"]]},
            {"type": "Update", "fields": [["Duration", 1]]},
            {"type": "Ramp", "fields": [["Duration", 4], ["CURRENT_DENSITY_SP", "$BASE_CD * 0.7"]]},
            {"type": "Update", "fields": [["Duration", 1]]},
            {"type": "Next", "fields": [["Next", "CountB"]]},
            {"type": "Ramp", "fields": [["Duration", 4], ["CURRENT_DENSITY_SP", "$BASE_CD"]]},
        ]})
    if FAST_PS["fcr"][0] in used:
        ps.append({"name": FAST_PS["fcr"][0], "steps": [
            {"type": "For", "comment": "15 regulation cycles: +/-0.2 A/cm2 around base, 2 min period", "fields": [["For", "CountB"], ["=", 1], ["To", 15], ["Step", 1]]},
            {"type": "Ramp", "fields": [["Duration", 10], ["CURRENT_DENSITY_SP", "$BASE_CD + 0.2"]]},
            {"type": "Update", "fields": [["Duration", 50]]},
            {"type": "Ramp", "fields": [["Duration", 10], ["CURRENT_DENSITY_SP", "$BASE_CD - 0.2"]]},
            {"type": "Update", "fields": [["Duration", 50]]},
            {"type": "Next", "fields": [["Next", "CountB"]]},
            {"type": "Ramp", "fields": [["Duration", 10], ["CURRENT_DENSITY_SP", "$BASE_CD"]]},
        ]})
    if XOVER_PS[0] in used:
        jup = rnd(max(2 * jmin, 0.3))
        ps.append({"name": XOVER_PS[0], "steps": [
            {"type": "Conditional", "comment": "Low-load safety: raise load if H2-in-O2 reaches 2 % (50 % LEL)",
             "fields": [["Duration", 1], ["MODE", "OR"], ["IF", "H2_IN_O2_FB"], ["GE", 2.0], ["THEN", ""],
                        ["CURRENT_DENSITY_SP", jup], ["MATRIX_COMMENT", f"H2-in-O2 >= 2 %: load raised to {jup} A/cm2"]]},
        ]})
    return ps


def vals(st, cols, label):
    d = {"MATRIX_COMMENT": label, "PSU_ENBL": "ON" if st.psu else "OFF", "CURRENT_DENSITY_SP": st.j,
         "TEMP_SP": st.T, "H2_PRESSURE_SP": st.P, "N2_PURGE": "ON" if st.purge else "OFF", "BASE_CD": st.j}
    return {k: d[k] for k in cols}


def build_script(sc, rng, target_h):
    v = sc["variant"]
    src = SC.SOURCES[sc["source"]]
    kind, blocks = blocks_for(sc, rng)
    per_block = [block_rows(b, v, True) for b in blocks]
    jmin = per_block[0][1]
    used = {DIAG_PS}
    for rows, _ in per_block:
        used |= {r["ps"] for r in rows if r["ps"]}
    has_fast = any(n in used for n, _ in FAST_PS.values())
    cols = ["MATRIX_COMMENT", "PSU_ENBL", "CURRENT_DENSITY_SP", "TEMP_SP", "H2_PRESSURE_SP"]
    if v["strategy"] == "purge":
        cols.append("N2_PURGE")
    if has_fast:
        cols.append("BASE_CD")

    diag_st = St(True, REF_J, v["T"], v["P"])
    diag_h = (REF_HOLD + ramp_needed(St(False, 0, v["T"], v["P"]), diag_st) + diag_time(v)) / 3600
    fixed_h = 4.0
    # iterations
    bh = [b.hours + diag_h for b in blocks]
    if kind == "seasonal":
        W = int((target_h - fixed_h) // (sum(bh) / 4))
        iters = [W // 4 + (1 if k < W % 4 else 0) for k in range(4)]
    elif kind == "single":
        iters = [int((target_h - fixed_h) // bh[0])]
    elif kind == "outage":
        W = int((target_h - fixed_h - bh[1]) // bh[0])
        iters = [W // 2, 1, W - W // 2]
        blocks = [blocks[0], blocks[1], blocks[0]]
        per_block = [per_block[0], per_block[1], per_block[0]]
    else:
        iters = [int((target_h - fixed_h) // bh[0])]
    iters = [max(1, n) for n in iters]

    mrows = []
    def emit(rows, prev_states, full_first, code):
        nonlocal mrows
        out = []
        prev = prev_states[0]
        for k, r in enumerate(rows):
            st = r["st"]
            ramp = max(ramp_needed(p, st) for p in (prev_states if k == 0 else [prev]))
            pst = ps_time(r["ps"], v) if r["ps"] else 0
            dur = r["time"] - ramp - pst
            assert dur >= 0, (sc["id"], r, ramp, pst)
            label = f"{code} {r['comment'].split(' +')[0]}"[:40]
            full = vals(st, cols, label)
            if k == 0 and full_first:
                values = full
            else:
                pv = vals(prev, cols, None)
                values = {c: full[c] for c in cols if c == "MATRIX_COMMENT" or full[c] != pv[c]}
            row = {"comment": r["comment"], "duration": int(dur), "ramp": int(ramp), "values": values}
            if r["ps"]:
                row["poststep"] = r["ps"]
            out.append(row)
            prev = st
        return out, prev

    pre_state = St(False, 0.0, v["T"], v["P"])
    mrows.append({"header": f"{src[1]} | {SC.STRAT_TEXT[v['strategy']]} | j_rated {v['jr']} A/cm2, {v['T']} C, {v['P']} barg"})
    bot, _ = emit([dict(st=diag_st, time=REF_HOLD + RAMP_J + diag_time(v), ps=DIAG_PS, comment="Beginning-of-test diagnostics: reference hold 1.0 A/cm2 + polarisation curve")],
                  [pre_state], True, "BoT")
    mrows += bot
    for bi, (b, (rows, _), n) in enumerate(zip(blocks, per_block, iters)):
        diag_row = dict(st=diag_st, time=None, ps=DIAG_PS, comment="Periodic diagnostics: reference hold 1.0 A/cm2 + polarisation curve")
        last = rows[-1]["st"]
        diag_row["time"] = REF_HOLD + ramp_needed(last, diag_st) + diag_time(v)
        mrows.append({"header": f"Block {bi + 1}: {b.name} ({b.hours:g} h) x {n}, diagnostics after each"})
        if n > 1:
            mrows.append({"loop": f"For CountA = 1 to {n}"})
        body, _ = emit(rows + [diag_row], [diag_st], True, b.label)
        mrows += body
        if n > 1:
            mrows.append({"loop": "Next CountA"})
    eot, _ = emit([dict(st=diag_st, time=REF_HOLD + diag_time(v), ps=DIAG_PS, comment="End-of-test diagnostics: reference hold 1.0 A/cm2 + polarisation curve")],
                  [diag_st], False, "EoT")
    mrows += eot

    pretest = [
        {"type": "Update", "comment": "Safe starting state", "fields": [["Duration", 5], ["MATRIX_COMMENT", "Pretest: safe state"], ["PSU_ENBL", "OFF"], ["CURRENT_DENSITY_SP", 0],
                                                                    ["BASE_CD", 0], ["N2_PURGE", "OFF"], ["H2_PRESSURE_SP", 0], ["TEMP_SP", 25], ["WATER_FLOW_SP", 0],
                                                                    ["SAFETY_CELL_V_HIHI", 2.5], ["CountA", 1], ["CountB", 1]]},
        {"type": "Update", "comment": "Start anode water circulation", "fields": [["Duration", 120], ["WATER_FLOW_SP", WATER], ["MATRIX_COMMENT", "Pretest: water on"]]},
        {"type": "Ramp", "comment": f"Heat to {v['T']} C at 2 C/min", "fields": [["Duration", (v["T"] - 25) * S_PER_DEGC], ["TEMP_SP", v["T"]]]},
        {"type": "Wait Til Settled", "fields": [["MODE", "AND"], ["Duration", 1800], ["Condition", "Stable"], ["Tag Value", "TEMP_FB"],
                                                ["Setpoint", "$TEMP_SP"], ["Range", 1.5], ["Set Time", 300]]},
    ]
    if v["P"] > 0:
        pretest.append({"type": "Ramp", "comment": f"Pressurise H2 side to {v['P']} barg at 1 bar/min",
                        "fields": [["Duration", v["P"] * S_PER_BAR], ["H2_PRESSURE_SP", v["P"]]]})
    posttest = [
        {"type": "Update", "fields": [["Duration", 5], ["MATRIX_COMMENT", "Posttest: shutdown"]]},
        {"type": "Ramp", "comment": "Unload", "fields": [["Duration", 60], ["CURRENT_DENSITY_SP", 0]]},
        {"type": "Update", "fields": [["Duration", 10], ["PSU_ENBL", "OFF"], ["BASE_CD", 0]]},
    ]
    if v["P"] > 0:
        posttest.append({"type": "Ramp", "comment": "Depressurise at 1 bar/min", "fields": [["Duration", v["P"] * S_PER_BAR], ["H2_PRESSURE_SP", 0]]})
    posttest += [
        {"type": "Ramp", "comment": "Cool to 25 C at 2 C/min", "fields": [["Duration", (v["T"] - 25) * S_PER_DEGC], ["TEMP_SP", 25]]},
        {"type": "Update", "comment": "N2 purge of the H2 side", "fields": [["Duration", 600], ["N2_PURGE", "ON"]]},
        {"type": "Update", "comment": "Safe state (tag defaults)", "fields": [["Duration", 5], ["N2_PURGE", "OFF"], ["WATER_FLOW_SP", 0], ["MATRIX_COMMENT", "Finished"]]},
    ]
    script = {
        "script_name": sc["sheet"],
        "notes": [],
        "pretest": pretest,
        "matrix": {"tags": cols, "rows": mrows},
        "poststeps": poststeps(v, used, jmin),
        "posttest": posttest,
    }
    return script, dict(kind=kind, iters=iters, jmin=jmin, blocks=[b.name for b in blocks], cols=cols)


# ============================================================ simulator
class Sim:
    def __init__(self, v):
        self.v = v
        self.t = 0.0
        self.var = {"PSU_ENBL": "OFF", "CURRENT_DENSITY_SP": 0.0, "TEMP_SP": 25.0, "H2_PRESSURE_SP": 0.0,
                    "N2_PURGE": "OFF", "WATER_FLOW_SP": 0.0, "BASE_CD": 0.0, "CountA": 1, "CountB": 1}
        self.pts = []          # (t, j, T, P, psu)
        self.events = []
        self.problems = []
        self.on_time = 0.0
        self.starts = 0
        self.charge = 0.0      # integral of j dt (A h / cm2)
        self.diag_t = []
        self.rec()

    def rec(self):
        g = self.var
        self.pts.append((self.t, float(g["CURRENT_DENSITY_SP"]), float(g["TEMP_SP"]), float(g["H2_PRESSURE_SP"]), g["PSU_ENBL"] == "ON"))

    def ev(self, x):
        if isinstance(x, (int, float)):
            return float(x)
        s = str(x)
        if "$" not in s:
            return float(s) if re.fullmatch(r"[-+0-9.eE]+", s) else s
        expr = re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)", lambda m: repr(float(self.var[m.group(1)])), s)
        return float(eval(expr, {"__builtins__": {}}, {}))

    def advance(self, dt):
        if dt <= 0:
            return
        if self.var["PSU_ENBL"] == "ON":
            self.on_time += dt
        self.charge += float(self.var["CURRENT_DENSITY_SP"]) * dt / 3600
        self.t += dt

    def check_rates(self, old, new, dt):
        for tag, lim, unit in (("TEMP_SP", 2.0, "C/min"), ("H2_PRESSURE_SP", 1.0, "bar/min")):
            d = abs(float(new.get(tag, old[tag])) - float(old[tag]))
            if d > 1e-9:
                rate = d / (dt / 60) if dt > 0 else float("inf")
                if rate > lim * 1.001:
                    self.problems.append(f"t={self.t / 3600:.2f}h {tag} changes {d:g} in {dt}s ({rate:.2f} {unit} > {lim})")

    def apply(self, changes, ramp):
        """Discrete changes at once, analog ramp linearly over `ramp` seconds."""
        old = dict(self.var)
        if "PSU_ENBL" in changes and changes["PSU_ENBL"] == "ON" and old["PSU_ENBL"] != "ON":
            self.starts += 1
            if float(changes.get("WATER_FLOW_SP", old["WATER_FLOW_SP"])) < 50:
                self.problems.append(f"t={self.t / 3600:.2f}h PSU on without water flow")
            if changes.get("N2_PURGE", old["N2_PURGE"]) == "ON":
                self.problems.append(f"t={self.t / 3600:.2f}h PSU on during N2 purge")
        if changes.get("N2_PURGE") == "ON":
            if changes.get("PSU_ENBL", old["PSU_ENBL"]) == "ON" or float(changes.get("H2_PRESSURE_SP", old["H2_PRESSURE_SP"])) > 0:
                self.problems.append(f"t={self.t / 3600:.2f}h N2 purge while PSU on or pressurised")
        self.check_rates(old, changes, ramp)
        for k, x in changes.items():
            if k in ("PSU_ENBL", "N2_PURGE", "MATRIX_COMMENT"):
                self.var[k] = x
        self.rec()
        analog = {k: float(x) for k, x in changes.items() if k not in ("PSU_ENBL", "N2_PURGE", "MATRIX_COMMENT")}
        if ramp > 0 and analog:
            # integrate charge over linear ramp of current
            j0 = float(self.var["CURRENT_DENSITY_SP"]); j1 = analog.get("CURRENT_DENSITY_SP", j0)
            if self.var["PSU_ENBL"] == "ON":
                self.on_time += ramp
            self.charge += (j0 + j1) / 2 * ramp / 3600
            self.t += ramp
            self.var.update(analog)
            self.rec()
        else:
            self.var.update(analog)
            self.advance(ramp)
            self.rec()
        if self.var["PSU_ENBL"] == "OFF" and float(self.var["CURRENT_DENSITY_SP"]) > 0:
            self.problems.append(f"t={self.t / 3600:.2f}h current set while PSU off")

    def hold(self, dt):
        self.advance(dt)
        self.rec()

    def run_steps(self, steps):
        i = 0
        stack = []
        while i < len(steps):
            st = steps[i]
            ty = st["type"]
            F = st["fields"]
            fd = {k: x for k, x in F}
            if ty == "Update":
                ch = {k: self.ev(x) for k, x in F if k != "Duration"}
                ch = {k: x for k, x in ch.items()}
                for k in ch:
                    if k in ("CountA", "CountB"):
                        self.var[k] = ch[k]
                self.apply({k: x for k, x in ch.items() if k not in ("CountA", "CountB", "SAFETY_CELL_V_HIHI")}, 0)
                self.hold(float(fd.get("Duration", 0)))
            elif ty == "Ramp":
                ch = {k: self.ev(x) for k, x in F if k != "Duration"}
                self.apply(ch, float(fd.get("Duration", 0)))
            elif ty == "Wait Til Settled":
                self.hold(SETTLE_EST if st is not None else 0)
            elif ty == "Wait Til":
                self.hold(60)
            elif ty == "Conditional":
                self.hold(float(fd.get("Duration", 0)))
            elif ty == "For":
                var = fd["For"]
                self.var[var] = self.ev(fd["="])
                stack.append((var, i, self.ev(fd["To"]), self.ev(fd.get("Step", 1))))
            elif ty == "Next":
                var, start, end, step = stack[-1]
                self.var[var] += step
                if self.var[var] <= end + 1e-9:
                    i = start + 1
                    continue
                stack.pop()
            i += 1

    def run_script(self, sc_json):
        self.run_steps(sc_json["pretest"])
        self.pretest_end = self.t
        ps = {p["name"]: p["steps"] for p in sc_json["poststeps"]}
        rows = sc_json["matrix"]["rows"]
        i, loop = 0, None
        while i < len(rows):
            r = rows[i]
            if "header" in r:
                i += 1; continue
            if "loop" in r:
                m = re.match(r"For (\w+) = (\d+) to (\d+)", r["loop"])
                if m:
                    loop = [i, int(m.group(2)), int(m.group(3))]
                else:  # Next
                    loop[1] += 1
                    if loop[1] <= loop[2]:
                        i = loop[0] + 1; continue
                    loop = None
                i += 1; continue
            if "diagnostics" in r["comment"].lower():
                self.diag_t.append(self.t)
            self.apply({k: x for k, x in r["values"].items()}, r["ramp"])
            self.hold(r["duration"])
            if r.get("poststep"):
                self.run_steps(ps[r["poststep"]])
            i += 1
        self.matrix_end = self.t
        self.run_steps(sc_json["posttest"])


# ============================================================ plotting
def plot(sc, script, sim, meta, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    v = sc["variant"]
    a = np.array([(t / 3600, j, T, Pp, 1.0 if on else 0.0) for t, j, T, Pp, on in sim.pts])
    th, j, T, Pp, on = a.T
    fig = plt.figure(figsize=(13, 8.6), dpi=100)
    gs = fig.add_gridspec(3, 1, height_ratios=[2.2, 1.2, 2.0], hspace=0.42)
    c_j, c_T, c_P, c_d = "#2457c5", "#c0392b", "#7d3cbd", "#e08e0b"
    ax1 = fig.add_subplot(gs[0])
    ax1.plot(th, j, color=c_j, lw=0.5)
    ax1.fill_between(th, 0, j, color=c_j, alpha=0.18, lw=0)
    for d in sim.diag_t:
        ax1.axvline(d / 3600, color=c_d, lw=0.6, alpha=0.6)
    ax1.set_xlim(0, th[-1]); ax1.set_ylim(0, max(3.0, j.max() * 1.05))
    ax1.set_ylabel("Current density SP\n(A/cm²)")
    ax1.set_title(f"Full test: {th[-1]:,.0f} h   (orange lines = diagnostics)", loc="left", fontsize=10, color="#444")
    ax1.axhline(v["jr"], color="#999", lw=0.6, ls="--"); ax1.text(th[-1], v["jr"], " rated", va="center", fontsize=8, color="#777")

    ax2 = fig.add_subplot(gs[1], sharex=ax1)
    ax2.plot(th, T, color=c_T, lw=0.9); ax2.set_ylabel("Temp SP (°C)", color=c_T); ax2.set_ylim(15, 90)
    ax2b = ax2.twinx(); ax2b.plot(th, Pp, color=c_P, lw=0.9); ax2b.set_ylabel("H₂ pressure SP\n(barg)", color=c_P); ax2b.set_ylim(-1, 32)
    ax2.set_xlabel("Test time (h)")

    # zoom: first 7 days after the BoT diagnostics (or first block for compressed tests)
    z0 = sim.diag_t[0] / 3600 if sim.diag_t else 0
    z1 = min(th[-1], z0 + (168 if meta["kind"] != "accel" else 48))
    ax3 = fig.add_subplot(gs[2])
    m = (th >= z0) & (th <= z1)
    idx = np.where(m)[0]
    if len(idx):                       # include the neighbouring points so long holds crossing the window edge are drawn
        m[max(0, idx[0] - 1)] = True
        m[min(len(m) - 1, idx[-1] + 1)] = True
    real = th > z0 + 1e-3
    ax3.plot(th[m] - z0, j[m], color=c_j, lw=0.8)
    ax3.fill_between(th[m] - z0, 0, j[m], color=c_j, alpha=0.18, lw=0)
    off = (on[m] < 0.5) & real[m]
    if off.any():
        ax3.fill_between(th[m] - z0, 0, max(3.0, j.max()), where=off, color="#888", alpha=0.12, lw=0, step="post", label="PSU off")
        ax3.legend(loc="upper right", fontsize=8, frameon=False)
    ax3.set_xlim(0, z1 - z0); ax3.set_ylim(0, max(3.0, j.max() * 1.05))
    ax3.set_ylabel("Current density SP\n(A/cm²)"); ax3.set_xlabel("Hours from beginning-of-test diagnostics")
    ax3.set_title(f"Zoom: first {z1 - z0:.0f} h (shows fast PostStep dynamics)", loc="left", fontsize=10, color="#444")
    if meta["kind"] != "accel":
        for d in range(1, int((z1 - z0) // 24) + 1):
            ax3.axvline(d * 24, color="#ccc", lw=0.5)
    for ax in (ax1, ax2, ax3):
        ax.grid(alpha=0.25, lw=0.5)
        for s in ("top",):
            ax.spines[s].set_visible(False)
    src = SC.SOURCES[sc["source"]]
    fig.suptitle(f"{sc['id']}  {src[1]}", x=0.06, ha="left", fontsize=14, fontweight="bold", y=0.985)
    fig.text(0.06, 0.935, f"{SC.STRAT_TEXT[v['strategy']]} · j_rated {v['jr']} A/cm² · j_min {meta['jmin']} A/cm² · {v['T']} °C · {v['P']} barg · "
             f"{sim.starts} PSU starts · utilisation {meta['util'] * 100:.0f} %", fontsize=10, color="#333")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


# ============================================================ main
def short_tag(v):
    parts = []
    if v["strategy"] != "minload": parts.append({"standby": "SB", "protective": "PC", "purge": "PG"}[v["strategy"]])
    if v["jr"] != 2.0: parts.append(f"j{v['jr']:g}")
    if v["jmin_frac"] != 0.08: parts.append(f"jm{int(v['jmin_frac'] * 100)}")
    if v["T"] != 70: parts.append(f"{v['T']}C")
    if v["P"] != 0: parts.append(f"{v['P']}b")
    if not v.get("flicker", True): parts.append("noflk")
    if v.get("gusts"): parts.append("gust")
    for k, lab in (("batt_h", "b{}h"), ("smooth_h", "s{}h"), ("run_pct", "r{}")):
        if k in v: parts.append(lab.format(v[k]))
    return " ".join(parts) or "ML"


def main(only=None):
    os.makedirs(os.path.join(OUT, "json"), exist_ok=True)
    os.makedirs(os.path.join(OUT, "graphs"), exist_ok=True)
    plan = SC.build_plan()
    catalog, bad = [], []
    for k, sc in enumerate(plan):
        if only and sc["id"] not in only:
            continue
        rng = np.random.default_rng(1000 + k)
        target = float(rng.uniform(1050, 3950))
        tag = short_tag(sc["variant"])
        sc["sheet"] = f"{sc['id']} {sc['source']} {tag}"[:31]
        sc["file"] = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{sc['id']}_{sc['source']}_{tag}")
        script, meta = build_script(sc, rng, target)
        sim = Sim(sc["variant"]); sim.run_script(script)
        hours = sim.t / 3600
        meta["util"] = sim.charge / (sc["variant"]["jr"] * hours)
        if not (1000 <= hours <= 4000):
            sim.problems.append(f"total {hours:.0f} h outside 1000-4000 h")
        if sim.problems:
            bad.append((sc["id"], sim.problems[:5]))
        oq = SC.open_questions(sc)
        src = SC.SOURCES[sc["source"]]
        info = dict(id=sc["id"], sheet=sc["sheet"], file=sc["file"], category=src[0], source=src[1], source_key=sc["source"],
                    group=sc["group"], strategy=SC.STRAT_TEXT[sc["variant"]["strategy"]], j_rated=sc["variant"]["jr"],
                    j_min=meta["jmin"], T=sc["variant"]["T"], P=sc["variant"]["P"], hours=round(hours, 1),
                    hours_on=round(sim.on_time / 3600, 1), psu_starts=sim.starts, diagnostics=len(sim.diag_t),
                    utilisation=round(meta["util"], 3), charge_Ah_cm2=round(sim.charge, 1), blocks=meta["blocks"],
                    iterations=meta["iters"], matrix_rows=sum(1 for r in script["matrix"]["rows"] if "comment" in r),
                    poststeps=[p["name"] for p in script["poststeps"]], open_questions=oq, assumptions=SC.GLOBAL_Q,
                    variant=sc["variant"])
        script["_info"] = info
        with open(os.path.join(OUT, "json", sc["file"] + ".json"), "w") as f:
            json.dump(script, f)
        plot(sc, script, sim, meta, os.path.join(OUT, "graphs", sc["file"] + ".png"))
        catalog.append(info)
        print(f"{sc['id']} {hours:7.0f} h  starts {sim.starts:4d}  util {meta['util']:.2f}  rows {info['matrix_rows']:4d}  {sc['sheet']}", flush=True)
    with open(os.path.join(OUT, "catalog.json"), "w") as f:
        json.dump(catalog, f, indent=1)
    print("PROBLEMS:", bad if bad else "none")
    return bad


if __name__ == "__main__":
    main(set(sys.argv[1:]) or None)
