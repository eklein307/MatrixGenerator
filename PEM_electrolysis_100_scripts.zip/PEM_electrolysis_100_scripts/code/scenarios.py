"""100 PEM-electrolysis test scenarios driven by simulated energy sources."""
import numpy as np
import profiles as P

SEASONS = ["winter", "spring", "summer", "autumn"]

# ------------------------------------------------------------------ sources
# kind: seasonal (4 representative weeks), single (1 week), outage (ops + outage + ops), accel (compressed)
def _pv(site, tracker=False):
    return lambda rng, s, v: P.pv_week(rng, site, s, flicker=v.get("flicker", True), tracker=tracker)

def _wind(site):
    return lambda rng, s, v: P.wind_week(rng, site, s, gusts=v.get("gusts", False))

def _hybrid(rng, s, v):
    pv, f = P.pv_week(rng, "midlat", s, flicker=v.get("flicker", True))
    w, _ = P.wind_week(rng, "onshore", s)
    return [min(1, 0.55 * a + 0.65 * b) for a, b in zip(pv, w)], f

def _pv_batt(rng, s, v):
    pv, f = P.pv_week(rng, "desert", s, flicker=False)
    return P.battery_shift([min(1, 1.25 * x) for x in pv], hours=v.get("batt_h", 4)), f

def _wind_batt(rng, s, v):
    w, _ = P.wind_week(rng, "onshore", s)
    return P.smooth(w, v.get("smooth_h", 6)), {}

def _island(rng, s, v):
    pv, f = P.pv_week(rng, "tropical", s, flicker=v.get("flicker", True))
    w, _ = P.wind_week(rng, "lowwind", s)
    return [min(1, 0.45 * a + 0.35 * b) for a, b in zip(pv, w)], f

def _csp(rng, s, v):
    pv, _ = P.pv_week(rng, "desert", s, flicker=False)
    out, k = [], P.SEASON_IDX[s]
    store_end = 26 if k > 0 else (24 if k == 0 else 22)   # hour (can exceed 24 = after midnight)
    for d in range(7):
        day = pv[d * 24:(d + 1) * 24]
        sunny = sum(day) / max(1, sum(1 for x in day if x > 0))
        for h in range(24):
            hh = h if h >= 6 else h + 24
            on = (day[h] > 0.15) or (8 <= hh < store_end and sunny > 0.4)
            out.append(0.95 if on else 0.0)
    return out, {}

def _hydro_ror(rng, s, v):
    lvl = {"winter": 0.35, "spring": 1.0, "summer": 0.75, "autumn": 0.5}[s]
    noise = P.smooth(rng.normal(0, 0.12, 168), 12)
    return [lvl + n for n in noise], {}

def _reservoir(rng, s, v):
    return [1.0 if (d >= 5 or h >= 22 or h < 6) else 0.0 for d in range(7) for h in range(24)], {}

def _tidal(rng, s, v):
    return P.tidal_week(rng, offset_h=float(rng.uniform(0, 12))), {}

def _wave(rng, s, v):
    mean = {"winter": 0.75, "spring": 0.55, "summer": 0.35, "autumn": 0.6}[s]
    x = P.smooth(rng.normal(0, 0.18, 168), 6)
    p = [mean + n for n in x]
    fast = {i: "wave" for i, q in enumerate(p) if 0.3 < q < 0.75 and rng.random() < 0.25}
    return p, fast

def _const(level):
    return lambda rng, s, v: ([level] * 168, {})

def _nuc_follow(rng, s, v):
    return [(0.6 if d >= 5 else (0.5 if 10 <= h < 16 else 1.0)) for d in range(7) for h in range(24)], {}

def _geo(rng, s, v):
    return [0.7 if (d == 2 and 8 <= h < 12) else 0.95 for d in range(7) for h in range(24)], {}

def _otec(rng, s, v):
    lvl = {"winter": 0.75, "spring": 0.85, "summer": 0.95, "autumn": 0.85}[s]
    return [lvl] * 168, {}

def _biogas(rng, s, v):
    return [1.0 if 6 <= h < 22 else 0.0 for d in range(7) for h in range(24)], {}

def _price(rng, s, v):
    pr = P.price_week(rng, s)
    thr = float(np.percentile(pr, v.get("run_pct", 40)))
    return [1.0 if x <= thr else 0.0 for x in pr], {}

def _carbon(rng, s, v):
    ci = P.carbon_week(rng, s)
    thr = float(np.percentile(ci, 45))
    return [1.0 if x <= thr else 0.25 for x in ci], {}

def _fcr(rng, s, v):
    return [0.5] * 168, {i: "fcr" for i in range(168) if i % 2 == 0}

def _afrr(rng, s, v):
    lvl, out = 0.6, []
    for i in range(168):
        if rng.random() < 0.5:
            lvl = float(np.clip(lvl + rng.choice([-0.2, -0.1, 0.1, 0.2]), 0.3, 1.0))
        out.append(lvl)
    return out, {}

def _curtail(rng, s, v):
    pv, _ = P.pv_week(rng, "midlat", s, flicker=False)
    w, _ = P.wind_week(rng, "onshore", s)
    out = []
    for i, (a, b) in enumerate(zip(pv, w)):
        h = i % 24
        demand = 0.55 + 0.25 * (7 <= h < 22)
        out.append(max(0.0, min(1.0, 2.2 * (1.3 * a + 1.1 * b - demand))))
    return out, {}

def _dr(rng, s, v):
    p = [0.9] * 168
    for _ in range(3):
        st, ln = int(rng.integers(0, 160)), int(rng.integers(1, 5))
        for i in range(st, min(168, st + ln)):
            p[i] = 0.0
    return p, {}

def _accel_pv(rng, s, v):
    p, _ = P.pv_week(rng, "desert", "summer", flicker=False, days=49)
    return p, {}

def _accel_wind(rng, s, v):
    p, _ = P.wind_week(rng, "onshore", "winter", n=24 * 21)
    return p, {}

def _accel_mixed(rng, s, v):
    p, _ = P.pv_week(rng, "midlat", "spring", flicker=False, days=49)
    return p, {}


SOURCES = {
    # key: (category, display, kind, fn, open questions)
    "pv_desert":   ("Solar PV", "PV, desert (25 N)", "seasonal", _pv("desert"),
                    ["How much voltage decay comes from the daily start/stop cycle (about 1 per day) compared with constant operation?",
                     "Does high midday load followed by long night idle accelerate catalyst dissolution?"]),
    "pv_midlat":   ("Solar PV", "PV, central Europe (50 N)", "seasonal", _pv("midlat"),
                    ["How do strong seasonal differences (short, cloudy winter days vs long summer days) change the degradation rate?",
                     "Are frequent cloudy-day partial loads worse than clear-day full cycles?"]),
    "pv_nordic":   ("Solar PV", "PV, Nordic (60 N)", "seasonal", _pv("nordic"),
                    ["Is winter operation (a few hours of low load per day) worth running, or should the stack be laid up for winter?",
                     "Do very long midsummer operating days behave like near-constant operation?"]),
    "pv_tropical": ("Solar PV", "PV, tropical with afternoon convection", "seasonal", _pv("tropical"),
                    ["Do afternoon convective cloud transients (simulated by the 'Cloud flicker' PostStep) cause extra degradation?"]),
    "pv_tracking": ("Solar PV", "PV, single-axis tracking (35 N)", "seasonal", _pv("tracking", tracker=True),
                    ["Does the broader, flatter tracking profile (longer time near rated load) reduce cycling damage compared with fixed-tilt PV?"]),
    "wind_onshore": ("Wind", "Wind, onshore plains", "seasonal", _wind("onshore"),
                    ["Does hour-to-hour load cycling between 10 and 100 % accelerate membrane thinning or catalyst loss?",
                     "How long can the stack sit at minimum load during calm periods without performance loss?"]),
    "wind_offshore": ("Wind", "Wind, offshore North Sea", "seasonal", _wind("offshore"),
                    ["What damage, if any, comes from storm cut-out events (sudden drop from rated load to zero)?",
                     "Is the high capacity factor close enough to constant operation to use a constant-load degradation model?"]),
    "wind_low":    ("Wind", "Wind, low-wind site", "seasonal", _wind("lowwind"),
                    ["With a low capacity factor, does idle time dominate degradation rather than operating hours?"]),
    "wind_coastal": ("Wind", "Wind, coastal sea breeze", "seasonal", _wind("coastal"),
                    ["Does a regular daily sea-breeze cycle behave like PV cycling, but shifted to afternoon and evening?"]),
    "wind_monsoon": ("Wind", "Wind, monsoon climate", "seasonal", _wind("monsoon"),
                    ["How does a strongly seasonal wind resource (high summer, weak rest of year) affect lifetime planning?"]),
    "pv_wind":     ("Hybrid", "PV + wind hybrid (central Europe)", "seasonal", _hybrid,
                    ["How much does combining PV and wind reduce the number of start/stop cycles compared with PV alone?"]),
    "pv_battery":  ("Hybrid", "PV + 4 h battery (desert)", "seasonal", _pv_batt,
                    ["How much battery capacity is needed before degradation becomes indistinguishable from constant operation?",
                     "Is it cheaper to buy battery capacity or to accept faster stack degradation?"]),
    "wind_battery": ("Hybrid", "Wind + battery smoothing", "seasonal", _wind_batt,
                    ["Does smoothing wind fluctuations over 6 h measurably reduce degradation?"]),
    "island":      ("Hybrid", "Off-grid island microgrid (PV + small wind)", "seasonal", _island,
                    ["Can an off-grid electrolyser with low utilisation and frequent zero-power periods reach an acceptable lifetime?"]),
    "csp":         ("Hybrid", "Concentrated solar power with thermal storage", "seasonal", _csp,
                    ["Does the long, flat CSP day (with storage into the evening) reduce cycling damage compared with PV?"]),
    "hydro_ror":   ("Hydro & marine", "Run-of-river hydro (snow-melt season)", "seasonal", _hydro_ror,
                    ["Does slow seasonal load variation produce degradation measurably different from constant load?"]),
    "hydro_res":   ("Hydro & marine", "Reservoir hydro, off-peak electrolysis", "single", _reservoir,
                    ["Is running only at nights and weekends (daily 16 h idle on weekdays) acceptable for stack life?"]),
    "tidal":       ("Hydro & marine", "Tidal stream (12.4 h cycle, spring-neap)", "single", _tidal,
                    ["Does the predictable 12.4 h cycle with slack-water zeros behave like PV cycling at twice the frequency?"]),
    "wave":        ("Hydro & marine", "Wave energy", "seasonal", _wave,
                    ["Do roughly 10 s power oscillations (simulated by the 'Wave oscillation' PostStep) need to be smoothed by power electronics before the stack?"]),
    "otec":        ("Hydro & marine", "Ocean thermal energy conversion", "seasonal", _otec,
                    ["Is near-constant, seasonally varying OTEC power a good reference case for marine hydrogen production?"]),
    "grid_base":   ("Firm & grid", "Grid, constant baseload", "single", _const(1.0),
                    ["What is the constant-load degradation baseline (uV/h) that all dynamic profiles should be compared with?"]),
    "nuclear_base": ("Firm & grid", "Nuclear baseload with refuelling outage", "outage", _const(0.95),
                    ["Does a 2-week refuelling outage in the middle of the test cause irreversible performance loss?"]),
    "nuclear_follow": ("Firm & grid", "Nuclear load-following (midday dip)", "single", _nuc_follow,
                    ["Does a daily 50 % midday dip (to make room for grid solar) add measurable degradation to baseload operation?"]),
    "geothermal":  ("Firm & grid", "Geothermal", "single", _geo,
                    ["Does short weekly maintenance derating matter at all for degradation?"]),
    "biogas":      ("Firm & grid", "Biogas CHP (heat-led, 16 h/day)", "single", _biogas,
                    ["Is a fixed daily 8 h shutdown better handled by hot standby or by full shutdown?"]),
    "grid_price":  ("Grid services", "Grid, spot-price arbitrage", "seasonal", _price,
                    ["What is the degradation cost of price-driven on/off cycling compared with the electricity cost saved?"]),
    "grid_carbon": ("Grid services", "Grid, low-carbon-hours operation", "seasonal", _carbon,
                    ["Does following grid carbon intensity (full load in low-carbon hours, 25 % otherwise) increase degradation?"]),
    "grid_fcr":    ("Grid services", "Grid, frequency containment reserve", "single", _fcr,
                    ["Can the stack provide +/-0.2 A/cm2 regulation every minute without extra degradation?",
                     "Is the stack response (seconds) fast enough to qualify for FCR?"]),
    "grid_afrr":   ("Grid services", "Grid, automatic frequency restoration reserve", "single", _afrr,
                    ["Do frequent hourly set-point changes for aFRR add degradation compared with constant operation?"]),
    "curtailment": ("Grid services", "Curtailed renewable surplus only", "seasonal", _curtail,
                    ["Is running only on curtailed surplus (low, irregular utilisation with long idle) technically viable?"]),
    "demand_resp": ("Grid services", "Interruptible load (demand response)", "single", _dr,
                    ["Do sudden unplanned interruptions with almost no ramp-down cause damage?"]),
    "accel_pv":    ("Accelerated", "Accelerated PV days (24 h compressed to 2 h)", "accel", _accel_pv,
                    ["Is degradation driven by the number of cycles or by time? Do compressed PV days reproduce field degradation per cycle?"]),
    "accel_wind":  ("Accelerated", "Accelerated wind (1 h compressed to 10 min)", "accel", _accel_wind,
                    ["Can six-fold compressed wind fluctuations be used as an accelerated stress test for wind-coupled electrolysis?"]),
    "accel_mixed": ("Accelerated", "Accelerated spring PV, central Europe (24 h compressed to 3 h)", "accel", _accel_mixed,
                    ["Do compressed cloudy-day profiles cause the same relative degradation ranking as real-time profiles?"]),
}

ACCEL_SLOT = {"accel_pv": 300, "accel_wind": 600, "accel_mixed": 450}

# ------------------------------------------------------------------ variants
# Each entry: (source, group label, [variant dicts]); variant keys:
#   strategy: minload | standby | protective | purge, jr: rated A/cm2, jmin_frac, T, P (barg), flicker, gusts
BASE = dict(strategy="minload", jr=2.0, jmin_frac=0.08, T=70, P=0, flicker=True, gusts=False)

def V(**k):
    d = dict(BASE); d.update(k); return d

IDLE3 = [V(strategy="minload"), V(strategy="standby"), V(strategy="protective")]
IDLE4 = IDLE3 + [V(strategy="purge")]
PRESS = [V(P=0), V(P=15), V(P=30)]
TEMP = [V(T=60), V(T=70), V(T=80)]
LOAD = [V(jr=1.5), V(jr=2.0), V(jr=2.5)]

PLAN = [
    ("pv_desert", "idle strategy", IDLE3),
    ("pv_midlat", "idle strategy", IDLE4),
    ("pv_nordic", "idle strategy", [V(strategy="minload"), V(strategy="purge"), V(strategy="standby")]),
    ("pv_tropical", "cloud transients", [V(flicker=True), V(flicker=False), V(flicker=True, P=30)]),
    ("pv_tracking", "rated load", LOAD),
    ("wind_onshore", "idle strategy", IDLE3),
    ("wind_offshore", "pressure", PRESS),
    ("wind_low", "minimum load", [V(jmin_frac=0.05), V(jmin_frac=0.10), V(jmin_frac=0.15)]),
    ("wind_coastal", "gust transients", [V(gusts=False), V(gusts=True), V(gusts=True, T=80)]),
    ("wind_monsoon", "temperature", TEMP),
    ("pv_wind", "idle strategy", IDLE3),
    ("pv_battery", "battery size", [V(batt_h=2), V(batt_h=4), V(batt_h=8)]),
    ("wind_battery", "smoothing window", [V(smooth_h=2), V(smooth_h=6), V(smooth_h=12)]),
    ("island", "idle strategy", [V(strategy="minload"), V(strategy="standby"), V(strategy="purge")]),
    ("csp", "pressure", PRESS),
    ("hydro_ror", "temperature", TEMP),
    ("hydro_res", "idle strategy", [V(strategy="standby"), V(strategy="purge"), V(strategy="protective")]),
    ("tidal", "idle strategy", IDLE3),
    ("wave", "rated load", LOAD),
    ("otec", "pressure", [V(P=0), V(P=30)]),
    ("grid_base", "rated load", [V(jr=1.0), V(jr=2.0), V(jr=3.0)]),
    ("nuclear_base", "outage handling", [V(strategy="standby"), V(strategy="purge"), V(strategy="protective")]),
    ("nuclear_follow", "temperature", TEMP),
    ("geothermal", "pressure", [V(P=0), V(P=30)]),
    ("biogas", "idle strategy", [V(strategy="standby"), V(strategy="purge"), V(strategy="protective")]),
    ("grid_price", "run hours", [V(run_pct=30, strategy="standby"), V(run_pct=50, strategy="standby"), V(run_pct=50, strategy="minload")]),
    ("grid_carbon", "pressure", [V(P=0), V(P=30)]),
    ("grid_fcr", "rated load", [V(jr=1.5), V(jr=2.0), V(jr=2.5)]),
    ("grid_afrr", "temperature", TEMP),
    ("curtailment", "idle strategy", IDLE4),
    ("demand_resp", "pressure", [V(P=0), V(P=15), V(P=30)]),
    ("accel_pv", "idle strategy", IDLE3),
    ("accel_wind", "idle strategy", [V(strategy="minload"), V(strategy="standby"), V(strategy="protective")]),
    ("accel_mixed", "rated load", [V(jr=1.5), V(jr=2.5)]),
]

STRAT_TEXT = {
    "minload": "minimum load", "standby": "hot standby (PSU off)", "protective": "protective current",
    "purge": "shutdown + N2 purge on long idle",
}
STRAT_Q = {
    "minload": "Is holding minimum load ({jmin:.2f} A/cm2) through low-availability periods better than switching off?",
    "standby": "Does repeated PSU off/on with water still circulating (open circuit) cause performance loss?",
    "protective": "Does a 0.02 A/cm2 protective current prevent reverse-current degradation, and is its H2-in-O2 crossover acceptable?",
    "purge": "Does full shutdown (depressurise, cool to 40 C, N2 purge) during idle periods of 6 h or more reduce degradation compared with hot standby?",
}
GLOBAL_Q = [
    "ASSUMPTION: profiles are synthetic and seeded. Should measured site data (irradiance, wind speed, prices) replace them?",
    "ASSUMPTION: power is mapped linearly to current (j = p x j_rated). Is a polarisation-curve-based mapping needed?",
    "ASSUMPTION: each representative week is replayed unchanged; real variability between weeks is larger.",
]


def build_plan():
    out, n = [], 0
    for src, group, variants in PLAN:
        for vi, v in enumerate(variants):
            n += 1
            out.append(dict(id=f"E{n:03d}", source=src, group=f"{src}: {group}", variant=v, vi=vi))
    assert len(out) == 100, len(out)
    return out


def open_questions(sc):
    src = SOURCES[sc["source"]]
    v = sc["variant"]
    q = list(src[4])
    q.append(STRAT_Q[v["strategy"]].format(jmin=v["jr"] * v["jmin_frac"]))
    if v["P"] >= 15:
        q.append(f"Does operating at {v['P']} barg increase crossover-related degradation under this profile compared with atmospheric operation?")
    if v["T"] >= 80:
        q.append("Does 80 C operation accelerate membrane degradation under cycling relative to 60-70 C?")
    if any(k == "flicker" for k in []) or (v.get("flicker") and SOURCES[sc["source"]][0] in ("Solar PV", "Hybrid")):
        q.append("Is hourly resolution enough, or do minute-level transients (approximated by 'Cloud flicker') change the result?")
    return q
