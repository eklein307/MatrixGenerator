"""Build gallery/index.html (+ gallery/graphs/*.png) from build/catalog.json."""
import json, os, shutil

ROOT = os.path.dirname(os.path.abspath(__file__))
B = os.path.join(ROOT, "build")
G = os.path.join(ROOT, "gallery")
cat = json.load(open(os.path.join(B, "catalog.json")))
os.makedirs(os.path.join(G, "graphs"), exist_ok=True)
for x in cat:
    shutil.copy(os.path.join(B, "graphs", x["file"] + ".png"), os.path.join(G, "graphs", x["file"] + ".png"))

data = [dict(id=x["id"], sheet=x["sheet"], file=x["file"], cat=x["category"], src=x["source"], group=x["group"].split(": ", 1)[1],
             strat=x["strategy"], jr=x["j_rated"], jmin=x["j_min"], T=x["T"], P=x["P"], h=x["hours"], hon=x["hours_on"],
             starts=x["psu_starts"], diag=x["diagnostics"], util=x["utilisation"], rows=x["matrix_rows"],
             blocks=[f"{b} ×{n}" for b, n in zip(x["blocks"], x["iterations"])], ps=x["poststeps"], oq=x["open_questions"])
        for x in cat]

HTML = r"""<title>PEM Electrolysis Script Set</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Condensed:wght@500;600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap">
<style>
/* Layout: sticky filter bar over a responsive card grid; a detail sheet opens over the grid (#E001 links to one script). */
:root {
  --bg: #f3f5f7; --surface: #ffffff; --ink: #14202b; --muted: #5a6a78; --line: #d9e0e6; --soft: #e8eef3;
  --accent: #0f6e8c; --accent-soft: #dcecf2; --h2: #2457c5; --warn: #9a5b00;
  --f-display: "IBM Plex Sans Condensed", "Arial Narrow", system-ui, sans-serif;
  --f-body: "IBM Plex Sans", system-ui, -apple-system, "Segoe UI", sans-serif;
  --f-mono: "IBM Plex Mono", ui-monospace, Consolas, monospace;
}
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) {
  --bg: #0f151b; --surface: #17202a; --ink: #e3eaf0; --muted: #93a3b1; --line: #2a3643; --soft: #1e2934;
  --accent: #5cc0dd; --accent-soft: #163543; --h2: #7ea4ff; --warn: #f0b860; color-scheme: dark } }
:root[data-theme="dark"] {
  --bg: #0f151b; --surface: #17202a; --ink: #e3eaf0; --muted: #93a3b1; --line: #2a3643; --soft: #1e2934;
  --accent: #5cc0dd; --accent-soft: #163543; --h2: #7ea4ff; --warn: #f0b860; color-scheme: dark }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
body { background: var(--bg); color: var(--ink); font: 15px/1.5 var(--f-body); margin: 0; }
.wrap { max-width: 1240px; margin: 0 auto; padding-left: max(16px, env(safe-area-inset-left, 0px)); padding-right: max(16px, env(safe-area-inset-right, 0px)); }
header.top { padding-block: 28px 18px; }
h1 { font: 600 30px/1.15 var(--f-display); margin: 0; text-wrap: balance; letter-spacing: .2px; }
.lede { color: var(--muted); margin: 6px 0 0; max-width: 72ch; }
.facts { display: flex; flex-wrap: wrap; gap: 8px 22px; margin-top: 16px; font-family: var(--f-mono); font-size: 13px; color: var(--muted); }
.facts b { color: var(--ink); font-weight: 500; }
body::before { content: ""; position: fixed; inset: 0 0 auto; height: env(safe-area-inset-top, 0px); z-index: 10; background: var(--bg); }
.bar { position: sticky; top: env(safe-area-inset-top, 0px); z-index: 5; background: var(--bg); border-bottom: 1px solid var(--line); }
@media (max-width: 700px) { .bar { position: static; } }
.bar .wrap { display: flex; flex-wrap: wrap; gap: 10px 14px; align-items: center; padding-block: 10px; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; }
.chip { border: 1px solid var(--line); background: var(--surface); color: var(--muted); border-radius: 99px; padding: 4px 11px; font: 500 13px var(--f-body); cursor: pointer; }
.chip[aria-pressed="true"] { background: var(--accent); border-color: var(--accent); color: var(--surface); }
.chip:focus-visible, select:focus-visible, input:focus-visible, .card:focus-visible, button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.ctl { display: flex; gap: 8px; flex-wrap: wrap; margin-left: auto; }
select, input[type=search] { font: 14px var(--f-body); color: var(--ink); background: var(--surface); border: 1px solid var(--line); border-radius: 7px; padding: 6px 9px; min-width: 0; }
input[type=search] { width: 200px; max-width: 100%; }
.count { font-family: var(--f-mono); font-size: 13px; color: var(--muted); }
main.wrap { padding-block: 18px 60px; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(290px, 1fr)); gap: 14px; }
.card { background: var(--surface); border: 1px solid var(--line); border-radius: 10px; overflow: hidden; cursor: pointer; display: flex; flex-direction: column; text-align: left; padding: 0; color: inherit; font: inherit; }
.card:hover { border-color: var(--accent); }
.thumb { aspect-ratio: 13 / 8.6; width: 100%; max-width: 100%; object-fit: cover; object-position: top left; background: #fff; display: block; border-bottom: 1px solid var(--line); }
.cbody { padding: 10px 12px 12px; display: grid; gap: 6px; min-width: 0; }
.idrow { display: flex; justify-content: space-between; gap: 8px; align-items: baseline; }
.id { font: 500 13px var(--f-mono); color: var(--accent); }
.catl { font-size: 11.5px; text-transform: uppercase; letter-spacing: .6px; color: var(--muted); }
.src { font: 600 16px/1.25 var(--f-display); margin: 0; }
.tags { display: flex; flex-wrap: wrap; gap: 4px; }
.tag { font: 12px var(--f-mono); background: var(--soft); color: var(--muted); border-radius: 5px; padding: 1px 6px; }
.tag.strat { background: var(--accent-soft); color: var(--accent); }
.stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px; font-variant-numeric: tabular-nums; border-top: 1px solid var(--line); padding-top: 7px; margin-top: 2px; }
.stats div { display: grid; }
.stats b { font: 500 15px var(--f-mono); }
.stats span { font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; }
.empty { color: var(--muted); padding: 40px 0; text-align: center; }
/* detail sheet */
.sheet { position: fixed; inset: 0; z-index: 20; background: color-mix(in srgb, var(--bg) 70%, transparent); display: flex; justify-content: center; align-items: flex-start; overflow-y: auto;
  padding: calc(16px + env(safe-area-inset-top, 0px)) max(12px, env(safe-area-inset-right, 0px)) calc(16px + env(safe-area-inset-bottom, 0px)) max(12px, env(safe-area-inset-left, 0px)); }
.panel { background: var(--surface); border: 1px solid var(--line); border-radius: 12px; width: min(1100px, 100%); padding: 18px; display: grid; gap: 14px; min-width: 0; }
.phead { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
.phead h2 { font: 600 24px/1.2 var(--f-display); margin: 2px 0 0; text-wrap: balance; }
.close { border: 1px solid var(--line); background: var(--surface); color: var(--ink); border-radius: 7px; padding: 6px 12px; font: 500 14px var(--f-body); cursor: pointer; flex: none; }
.big { width: 100%; max-width: 100%; border-radius: 8px; border: 1px solid var(--line); background: #fff; }
.cols { display: grid; grid-template-columns: 1fr 1.3fr; gap: 18px; }
@media (max-width: 760px) { .cols { grid-template-columns: 1fr; } }
dl.kv { display: grid; grid-template-columns: auto 1fr; gap: 4px 14px; margin: 0; font-size: 14px; }
dl.kv dt { color: var(--muted); }
dl.kv dd { margin: 0; font-family: var(--f-mono); font-size: 13px; overflow-wrap: anywhere; }
h3 { font: 600 13px var(--f-body); text-transform: uppercase; letter-spacing: .7px; color: var(--muted); margin: 0 0 6px; }
ol.oq { margin: 0; padding-left: 20px; display: grid; gap: 6px; }
ol.oq li.as { color: var(--muted); }
.files { font: 12.5px var(--f-mono); color: var(--muted); overflow-wrap: anywhere; }
.copy { border: 1px solid var(--line); background: var(--soft); color: var(--ink); border-radius: 6px; padding: 2px 8px; font: 12px var(--f-body); cursor: pointer; margin-left: 6px; }
@media (prefers-reduced-motion: no-preference) { .card { transition: border-color .15s; } }
</style>

<header class="top wrap">
  <h1>PEM Electrolysis Script Set</h1>
  <p class="lede">100 durability-test matrices for PEM water electrolysis, each driven by a simulated energy source and checked by the Test Script Generator. Select a card to see its full set-point preview and the open questions it is designed to answer.</p>
  <div class="facts" id="facts"></div>
</header>
<div class="bar"><div class="wrap">
  <div class="chips" id="cats" role="group" aria-label="Filter by category"></div>
  <div class="ctl">
    <select id="strat" aria-label="Idle strategy"><option value="">All idle strategies</option></select>
    <select id="sort" aria-label="Sort">
      <option value="id">Sort: ID</option><option value="h">Sort: longest test</option><option value="starts">Sort: most PSU starts</option><option value="util">Sort: highest utilisation</option>
    </select>
    <input type="search" id="q" placeholder="Search source, group, question" aria-label="Search">
  </div>
  <span class="count" id="count"></span>
</div></div>
<main class="wrap"><div class="grid" id="grid"></div><p class="empty" id="empty" hidden>No scripts match these filters.</p></main>
<div class="sheet" id="sheet" hidden><div class="panel" id="panel" role="dialog" aria-modal="true" aria-labelledby="ptitle"></div></div>

<script>
const DATA = __DATA__;
const ASSUME = 3;  // last 3 open questions are global assumptions
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const fmt = (n) => n.toLocaleString("en-US", { maximumFractionDigits: 0 });
const state = { cat: "", strat: "", sort: "id", q: "" };
try { Object.assign(state, JSON.parse(localStorage.getItem("pemgallery") || "{}")); } catch (e) {}

const hrs = DATA.map(d => d.h);
$("facts").innerHTML = [
  `<span><b>${DATA.length}</b> scripts</span>`,
  `<span><b>${new Set(DATA.map(d => d.src)).size}</b> energy sources</span>`,
  `<span><b>${fmt(Math.min(...hrs))}–${fmt(Math.max(...hrs))} h</b> per test</span>`,
  `<span><b>${fmt(hrs.reduce((a, b) => a + b, 0))} h</b> in total</span>`,
  `<span><b>${DATA.reduce((a, d) => a + d.oq.length, 0)}</b> open questions</span>`,
  `<span><b>0</b> checker errors</span>`].join("");

const cats = ["", ...new Set(DATA.map(d => d.cat))];
$("cats").innerHTML = cats.map(c => `<button class="chip" data-c="${esc(c)}" aria-pressed="false">${c ? esc(c) : "All"} <span class="n">${c ? DATA.filter(d => d.cat === c).length : DATA.length}</span></button>`).join("");
[...new Set(DATA.map(d => d.strat))].forEach(s => $("strat").insertAdjacentHTML("beforeend", `<option>${esc(s)}</option>`));

function card(d) {
  return `<button class="card" data-id="${d.id}" aria-label="${esc(d.id + " " + d.src)}">
    <img class="thumb" loading="lazy" src="graphs/${esc(d.file)}.png" alt="Set-point preview for ${esc(d.id)}">
    <div class="cbody">
      <div class="idrow"><span class="id">${d.id}</span><span class="catl">${esc(d.cat)}</span></div>
      <p class="src">${esc(d.src)}</p>
      <div class="tags"><span class="tag strat">${esc(d.strat)}</span><span class="tag">${d.jr} A/cm²</span><span class="tag">${d.T} °C</span><span class="tag">${d.P} barg</span></div>
      <div class="stats"><div><b>${fmt(d.h)}</b><span>hours</span></div><div><b>${fmt(d.starts)}</b><span>PSU starts</span></div><div><b>${Math.round(d.util * 100)}%</b><span>utilisation</span></div></div>
    </div></button>`;
}

function render() {
  try { localStorage.setItem("pemgallery", JSON.stringify(state)); } catch (e) {}
  document.querySelectorAll("#cats .chip").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.c === state.cat)));
  $("strat").value = state.strat; $("sort").value = state.sort; $("q").value = state.q;
  const q = state.q.trim().toLowerCase();
  let list = DATA.filter(d => (!state.cat || d.cat === state.cat) && (!state.strat || d.strat === state.strat) &&
    (!q || [d.id, d.src, d.group, d.strat, d.sheet, ...d.oq].join(" ").toLowerCase().includes(q)));
  const key = state.sort;
  list.sort((a, b) => key === "id" ? a.id.localeCompare(b.id) : b[key] - a[key]);
  $("grid").innerHTML = list.map(card).join("");
  $("empty").hidden = list.length > 0;
  $("count").textContent = `${list.length} shown`;
}

function openDetail(id) {
  const d = DATA.find(x => x.id === id);
  if (!d) { $("sheet").hidden = true; return; }
  const oq = d.oq.map((q, i) => `<li class="${i >= d.oq.length - ASSUME ? "as" : ""}">${esc(q)}</li>`).join("");
  $("panel").innerHTML = `
    <div class="phead"><div><span class="id">${d.id}</span> <span class="catl">· ${esc(d.cat)} · comparison group: ${esc(d.group)}</span><h2 id="ptitle">${esc(d.src)}</h2></div>
      <button class="close" id="close">Close</button></div>
    <img class="big" src="graphs/${esc(d.file)}.png" alt="Set-point preview for ${esc(d.id)}: current density, temperature and pressure over the full test, plus a one-week zoom">
    <div class="cols">
      <div><h3>Test conditions</h3><dl class="kv">
        <dt>Idle strategy</dt><dd>${esc(d.strat)}</dd>
        <dt>Rated / min load</dt><dd>${d.jr} / ${d.jmin} A/cm²</dd>
        <dt>Temperature</dt><dd>${d.T} °C</dd><dt>H₂ pressure</dt><dd>${d.P} barg</dd>
        <dt>Duration</dt><dd>${fmt(d.h)} h (${fmt(d.hon)} h PSU on)</dd>
        <dt>PSU starts</dt><dd>${fmt(d.starts)}</dd><dt>Diagnostic runs</dt><dd>${d.diag}</dd>
        <dt>Utilisation</dt><dd>${Math.round(d.util * 100)} % of rated</dd>
        <dt>Blocks</dt><dd>${d.blocks.map(esc).join("<br>")}</dd>
        <dt>Matrix rows</dt><dd>${d.rows}</dd><dt>PostSteps</dt><dd>${d.ps.map(esc).join(", ")}</dd>
      </dl></div>
      <div><h3>Open questions</h3><ol class="oq">${oq}</ol>
        <h3 style="margin-top:14px">Files</h3>
        <div class="files">scripts/${esc(d.file)}.xlsx<button class="copy" data-copy="${esc(d.sheet)}">Copy sheet name</button><br>graphs/${esc(d.file)}.png<br>Sheet in library workbook: ${esc(d.sheet)}</div>
      </div>
    </div>`;
  $("sheet").hidden = false;
  $("close").focus();
}

function route() { const id = location.hash.slice(1); if (/^E\d{3}$/.test(id)) openDetail(id); else $("sheet").hidden = true; }

$("cats").addEventListener("click", e => { const b = e.target.closest(".chip"); if (!b) return; state.cat = b.dataset.c; render(); });
$("strat").addEventListener("change", e => { state.strat = e.target.value; render(); });
$("sort").addEventListener("change", e => { state.sort = e.target.value; render(); });
$("q").addEventListener("input", e => { state.q = e.target.value; render(); });
$("grid").addEventListener("click", e => { const c = e.target.closest(".card"); if (c) location.hash = c.dataset.id; });
$("sheet").addEventListener("click", e => {
  if (e.target.id === "sheet" || e.target.id === "close") { history.replaceState(null, "", location.pathname + location.search); $("sheet").hidden = true; }
  const cp = e.target.closest(".copy");
  if (cp) { navigator.clipboard.writeText(cp.dataset.copy).then(() => { cp.textContent = "Copied"; }, () => { cp.textContent = cp.dataset.copy; }); }
});
document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("sheet").hidden) { history.replaceState(null, "", location.pathname + location.search); $("sheet").hidden = true; } });
window.addEventListener("hashchange", route);
render(); route();
</script>
"""
open(os.path.join(G, "index.html"), "w").write(HTML.replace("__DATA__", json.dumps(data, ensure_ascii=False)))
print("gallery written:", len(data), "cards;", os.path.getsize(os.path.join(G, "index.html")) // 1024, "KB")
