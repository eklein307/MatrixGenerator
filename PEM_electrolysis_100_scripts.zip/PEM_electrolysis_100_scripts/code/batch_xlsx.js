// Convert build/json/*.json to .xlsx using the Test Script Generator's own writer and checker.
// Usage: node batch_xlsx.js <path to script_generator.html> <tags csv>
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const TOOL = process.argv[2] || path.join(ROOT, '..', 'out', 'script_generator.html');
const TAGS = process.argv[3] || path.join(ROOT, 'tags_pem_electrolysis.csv');

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  await p.goto('file://' + path.resolve(TOOL));
  await p.setInputFiles('#tagFile', TAGS);
  const tagMsgs = await p.$$eval('#tagMsgs .msg', e => e.map(x => x.textContent));
  if (tagMsgs.length) console.log('Tag CSV messages:', tagMsgs);

  const files = fs.readdirSync(path.join(ROOT, 'build', 'json')).filter(f => f.endsWith('.json')).sort();
  fs.mkdirSync(path.join(ROOT, 'build', 'xlsx'), { recursive: true });
  await p.evaluate(() => { window.__lib = XLSX.utils.book_new(); });
  const report = [];
  for (const f of files) {
    const script = JSON.parse(fs.readFileSync(path.join(ROOT, 'build', 'json', f), 'utf8'));
    const r = await p.evaluate((script) => {
      const info = script._info;
      const sc = normalizeScript(script);
      const aoa = scriptToAOA(sc);
      const head = [
        ["//", `${info.id}: ${info.source} | ${info.strategy} | j_rated ${info.j_rated} A/cm2, j_min ${info.j_min} A/cm2 | ${info.T} C | ${info.P} barg`],
        ["//", `Estimated duration ${info.hours} h (${info.hours_on} h PSU on), ${info.psu_starts} PSU starts, ${info.diagnostics} diagnostic runs, utilisation ${Math.round(info.utilisation * 100)} %`],
        ["//", `Comparison group: ${info.group}. Synthetic profile; regenerate with gen.py to change assumptions.`],
        ...info.open_questions.map((q, i) => ["//", `OPEN QUESTION ${i + 1}: ${q}`]),
        ...info.assumptions.map(q => ["//", q]),
      ];
      aoa.splice(2, 0, ...head);
      const v = validate(aoa);
      const ws = XLSX.utils.aoa_to_sheet(aoa.map(r => r.map(c => (c === "" ? null : c))));
      const ncol = Math.max(...aoa.map(r => r.length));
      ws["!cols"] = Array.from({ length: ncol }, (_, c) => ({ wch: c === 0 ? 10 : c === 1 ? 46 : c === 4 ? 18 : 16 }));
      const name = safeSheetName(info.sheet);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, name);
      XLSX.utils.book_append_sheet(window.__lib, ws, name);
      return { b64: XLSX.write(wb, { type: "base64", bookType: "xlsx" }), name, rows: aoa.length,
               errors: v.issues.filter(i => i.level === "error").map(i => `row ${i.row + 1}: ${i.msg}`),
               warnings: v.issues.filter(i => i.level === "warning").map(i => `row ${i.row == null ? "-" : i.row + 1}: ${i.msg}`) };
    }, script);
    fs.writeFileSync(path.join(ROOT, 'build', 'xlsx', f.replace(/\.json$/, '.xlsx')), Buffer.from(r.b64, 'base64'));
    report.push({ file: f.replace(/\.json$/, '.xlsx'), sheet: r.name, sheet_rows: r.rows, errors: r.errors, warnings: r.warnings });
    console.log(`${r.name.padEnd(32)} rows ${String(r.rows).padStart(5)}  errors ${r.errors.length}  warnings ${r.warnings.length}${r.errors.length ? '  ' + r.errors.slice(0, 2).join(' | ') : ''}${r.warnings.length ? '  ' + r.warnings.slice(0, 2).join(' | ') : ''}`);
  }
  const lib = await p.evaluate(() => XLSX.write(window.__lib, { type: "base64", bookType: "xlsx" }));
  fs.writeFileSync(path.join(ROOT, 'build', 'PEM_electrolysis_library_100_scripts.xlsx'), Buffer.from(lib, 'base64'));
  fs.writeFileSync(path.join(ROOT, 'build', 'validation.json'), JSON.stringify(report, null, 1));
  const nE = report.reduce((a, r) => a + r.errors.length, 0), nW = report.reduce((a, r) => a + r.warnings.length, 0);
  console.log(`\n${report.length} scripts, ${nE} errors, ${nW} warnings. Page errors: ${errs.length ? errs : 'none'}`);
  await b.close();
})();
