"""Build the catalog workbook (and CSV) from build/catalog.json and build/validation.json."""
import csv, json, os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

B = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build")
cat = json.load(open(os.path.join(B, "catalog.json")))
val = {v["file"]: v for v in json.load(open(os.path.join(B, "validation.json")))}

HEAD = Font(bold=True, color="FFFFFF")
FILL = PatternFill("solid", fgColor="2457C5")
WRAP = Alignment(wrap_text=True, vertical="top")

wb = Workbook()
ws = wb.active
ws.title = "Catalog"
cols = [("ID", 7), ("Sheet name", 30), ("Category", 15), ("Energy source", 40), ("Comparison group", 32), ("Idle strategy", 26),
        ("j_rated (A/cm2)", 10), ("j_min (A/cm2)", 10), ("Temp (C)", 8), ("H2 pressure (barg)", 10), ("Duration (h)", 10),
        ("PSU on (h)", 10), ("PSU starts", 9), ("Diagnostic runs", 9), ("Utilisation", 10), ("Charge (Ah/cm2)", 10),
        ("Blocks x iterations", 44), ("Matrix rows", 8), ("PostSteps", 36), ("Checker errors", 8), ("Checker warnings", 8),
        ("Script file", 34), ("Graph file", 34), ("Open questions", 90)]
ws.append([c for c, _ in cols])
for i, (_, w) in enumerate(cols, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
    c = ws.cell(1, i); c.font = HEAD; c.fill = FILL; c.alignment = Alignment(wrap_text=True, vertical="center")
for x in cat:
    v = val[x["file"] + ".xlsx"]
    ws.append([x["id"], x["sheet"], x["category"], x["source"], x["group"], x["strategy"], x["j_rated"], x["j_min"], x["T"], x["P"],
               x["hours"], x["hours_on"], x["psu_starts"], x["diagnostics"], x["utilisation"], x["charge_Ah_cm2"],
               "; ".join(f"{b} x{n}" for b, n in zip(x["blocks"], x["iterations"])), x["matrix_rows"], ", ".join(x["poststeps"]),
               len(v["errors"]), len(v["warnings"]), "scripts/" + x["file"] + ".xlsx", "graphs/" + x["file"] + ".png",
               "\n".join(f"{i + 1}. {q}" for i, q in enumerate(x["open_questions"]))])
for row in ws.iter_rows(min_row=2):
    for c in row:
        c.alignment = WRAP
    row[14].number_format = "0%"
ws.freeze_panes = "C2"
ws.auto_filter.ref = ws.dimensions

# open questions, long format
wq = wb.create_sheet("Open questions")
wq.append(["ID", "Energy source", "Comparison group", "#", "Open question"])
for i, w in enumerate([7, 40, 32, 4, 120], 1):
    wq.column_dimensions[get_column_letter(i)].width = w
    c = wq.cell(1, i); c.font = HEAD; c.fill = FILL
for x in cat:
    for k, q in enumerate(x["open_questions"], 1):
        wq.append([x["id"], x["source"], x["group"], k, q])
for row in wq.iter_rows(min_row=2):
    row[4].alignment = WRAP
wq.freeze_panes = "A2"; wq.auto_filter.ref = wq.dimensions

# comparison groups
wg = wb.create_sheet("Comparison groups")
wg.append(["Comparison group", "Scripts", "What varies", "IDs"])
groups = {}
for x in cat:
    groups.setdefault(x["group"], []).append(x)
for i, w in enumerate([34, 8, 70, 40], 1):
    wg.column_dimensions[get_column_letter(i)].width = w
    c = wg.cell(1, i); c.font = HEAD; c.fill = FILL
for g, xs in groups.items():
    keys = set()
    for a in xs:
        for b in xs:
            for k in set(a["variant"]) | set(b["variant"]):
                if a["variant"].get(k) != b["variant"].get(k):
                    keys.add(k)
    desc = "; ".join(f"{k}: " + " / ".join(str(a['variant'].get(k)) for a in xs) for k in sorted(keys)) or "-"
    wg.append([g, len(xs), desc, ", ".join(a["id"] for a in xs)])
for row in wg.iter_rows(min_row=2):
    for c in row:
        c.alignment = WRAP

# assumptions
wa = wb.create_sheet("Assumptions")
wa.column_dimensions["A"].width = 130
wa.append(["Assumptions and global open questions (apply to every script)"]); wa["A1"].font = Font(bold=True)
for q in cat[0]["assumptions"] + [
    "ASSUMPTION: a matrix row's time is ramp + duration, and its PostStep runs after both (confirmed for PostStep order; ramp/hold sequencing assumed).",
    "ASSUMPTION: Wait Til Settled is estimated as Set Time + 60 s (360 s) for duration estimates and graphs; real time depends on the rig.",
    "ASSUMPTION: Wait Til and Conditional steps are assumed not to trigger (no low-voltage, H2-in-O2 or EoL events) in the simulation.",
    "ASSUMPTION: anode water flow is constant at 100 mL/min during the test; the PSU is always in current control.",
    "ASSUMPTION: rate limits enforced by the generator: temperature 2 C/min, H2 pressure 1 bar/min; current changes ramp over 30 s.",
    "ASSUMPTION: idle strategies: minimum load = jr x jmin_frac; protective current = 0.02 A/cm2; purge applies to idle periods of 6 h or more.",
    "DIAGNOSTICS: beginning, after every block iteration (about weekly), and end of test: 30 min at 1.0 A/cm2, EoL flag at 2.1 V, then a polarisation curve in 0.25 A/cm2 steps of 2 min up to j_rated.",
]:
    wa.append([q])
for row in wa.iter_rows(min_row=2):
    row[0].alignment = WRAP

wb.save(os.path.join(B, "catalog_100_scripts.xlsx"))
with open(os.path.join(B, "catalog_100_scripts.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow([c for c, _ in cols])
    for r in ws.iter_rows(min_row=2, values_only=True):
        w.writerow(r)
print("catalog written:", len(cat), "scripts,", len(groups), "groups")
